package com.mycompany.snackondgo;

public class Drinks extends FoodItem{
    String size;
    
    public Drinks(String name, double price, int quantity, String size){
        super(name, price, quantity);
        this.size = size;
    }
    
    public String getSize(){
        return size;
    }
    
    public void setSize(String size){
        this.size = size;
    }
    
    public void updatePrice(){
        if ("Large".equalsIgnoreCase(size)){
            double newPrice = getPrice()+20;
            setPrice(newPrice);
            updateName();
        }else {
            setPrice(getPrice());
        }
    }
    
    public void updateName(){
        setName(getName() + " Large");
    }
}
