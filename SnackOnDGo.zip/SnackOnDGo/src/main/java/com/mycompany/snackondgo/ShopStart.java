
package com.mycompany.snackondgo;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;



public class ShopStart extends javax.swing.JFrame {
    String orderTypes; //Dine in or Take out
    CardLayout cardLayout; // CardLayout for the foods and drinks
    DefaultTableModel model; // Table of carts
    
    ArrayList<FoodItem> cartItems; // Arraylist to insert all the orders

    public ShopStart() {
        initComponents();
        orderTypes = ""; // Set the type to Dine in or Take out
        Image icon = Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/logo.png");
        this.setIconImage(icon);
        
        dineIn.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/dineIn.png")));
        takeOut.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/takeaway.png")));
        firstLogo.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/logo.png")));
        
        shopLogo3.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/logo182.png")));
        shoplogo.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/logo182.png")));
        
        brownieImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/BRWNY-M1.jpg")));
        chickenImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/CHICKENBURGER.jpg")));
        spagImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/SPAG.jpg")));
        boxImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/HOLBRWNYBOX.jpg")));
        twisterImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/CALMAKITWISTER.jpg")));
        mashedImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/MASHED.jpg")));
        tComboImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/TWISTERCBO.jpg")));
        cornImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/BCORNPLT.jpg")));
        
        kingImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/AKZSMAC.jpg")));
        king2Img.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/AKZSMBCORNCBO.jpg")));
        spagMealImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/ASPAGCBO.jpg")));
        riceImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/RICE.jpg")));
        sisigImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/RBSISIG.jpg")));
        chickMealImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/SPAGMEAL.jpg")));
        
        coffeeImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/CFFEEFLOAT.jpg")));
        cokeImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/COKE-R.jpg")));
        cokeZeroImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/COKEZERO-R.jpg")));
        cokeFloatImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/COKEZEROFLOAT.jpg")));
        teaImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/ICEDTEA.jpg")));
        royalImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/ROYAL-R.jpg")));
        spriteImg.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/main/java/com/mycompany/snackondgo/icons/SPRITE-R.jpg")));
        
        cardLayout = (CardLayout)(pnlCards.getLayout());
        model = (DefaultTableModel) cartOrders.getModel();
        cartItems = new ArrayList<>();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTab = new javax.swing.JTabbedPane();
        startShop = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        firstLogo = new javax.swing.JLabel();
        orderType = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        dineIn = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        takeOut = new javax.swing.JLabel();
        shoplogo = new javax.swing.JLabel();
        mainApp = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        shopLogo3 = new javax.swing.JLabel();
        pnlCards = new javax.swing.JPanel();
        bluePnl = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        brownieImg = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        brownie = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        chickenImg = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        chickenBurger = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        spagImg = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        spaghetti = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        boxImg = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        boxBrownies = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        twisterImg = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        twister = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        mashedImg = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        mashed = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        tComboImg = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        twisterCombo = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        cornImg = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        butteredCorn = new javax.swing.JButton();
        greenPnl = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        kingImg = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        alaKing = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        king2Img = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        alaKingDrink = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        spagMealImg = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        spaghettiDrink = new javax.swing.JButton();
        jPanel22 = new javax.swing.JPanel();
        riceImg = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        rice = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        sisigImg = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        sisig = new javax.swing.JButton();
        jPanel24 = new javax.swing.JPanel();
        chickMealImg = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        spaghettiMeal = new javax.swing.JButton();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        violetPnl = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        coffeeImg = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        coffeeFloat = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        cokeImg = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        coke = new javax.swing.JButton();
        jPanel30 = new javax.swing.JPanel();
        cokeZeroImg = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        cokeZero = new javax.swing.JButton();
        jPanel31 = new javax.swing.JPanel();
        cokeFloatImg = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        cokeZeroFloat = new javax.swing.JButton();
        jPanel32 = new javax.swing.JPanel();
        teaImg = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        icedTea = new javax.swing.JButton();
        jPanel33 = new javax.swing.JPanel();
        royalImg = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        royal = new javax.swing.JButton();
        jPanel34 = new javax.swing.JPanel();
        spriteImg = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        sprite = new javax.swing.JButton();
        jPanel35 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        cartOrders = new javax.swing.JTable();
        removeItem = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        totalAmountOrders = new javax.swing.JLabel();
        placeOrder = new javax.swing.JButton();
        back = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SnackOnDGo");
        setIconImage(null);
        setIconImages(null);
        setSize(new java.awt.Dimension(1550, 680));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        startShop.setBackground(new java.awt.Color(255, 255, 255));
        startShop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                startShopMouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 0, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("START AN ORDER");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1550, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout startShopLayout = new javax.swing.GroupLayout(startShop);
        startShop.setLayout(startShopLayout);
        startShopLayout.setHorizontalGroup(
            startShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, startShopLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(firstLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(377, 377, 377))
        );
        startShopLayout.setVerticalGroup(
            startShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, startShopLayout.createSequentialGroup()
                .addContainerGap(80, Short.MAX_VALUE)
                .addComponent(firstLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        mainTab.addTab("tab1", startShop);

        orderType.setBackground(new java.awt.Color(0, 0, 153));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        dineIn.setFont(new java.awt.Font("Segoe UI Black", 1, 48)); // NOI18N
        dineIn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dineIn.setText("DINE IN");
        dineIn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dineInMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dineIn, javax.swing.GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dineIn, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        takeOut.setFont(new java.awt.Font("Segoe UI Black", 1, 48)); // NOI18N
        takeOut.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        takeOut.setText("TAKE OUT");
        takeOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                takeOutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(takeOut, javax.swing.GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(takeOut, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout orderTypeLayout = new javax.swing.GroupLayout(orderType);
        orderType.setLayout(orderTypeLayout);
        orderTypeLayout.setHorizontalGroup(
            orderTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(orderTypeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shoplogo, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addGroup(orderTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(399, Short.MAX_VALUE))
        );
        orderTypeLayout.setVerticalGroup(
            orderTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(orderTypeLayout.createSequentialGroup()
                .addGroup(orderTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(orderTypeLayout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(orderTypeLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(shoplogo, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(101, 101, 101)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(141, Short.MAX_VALUE))
        );

        mainTab.addTab("tab2", orderType);

        mainApp.setBackground(new java.awt.Color(0, 0, 153));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jButton4.setBackground(new java.awt.Color(0, 0, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("SNACKS");
        jButton4.setBorder(null);
        jButton4.setBorderPainted(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.setFocusPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 0, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("MEALS");
        jButton5.setBorder(null);
        jButton5.setBorderPainted(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.setFocusPainted(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 0, 153));
        jButton6.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("DRINKS");
        jButton6.setBorder(null);
        jButton6.setBorderPainted(false);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setFocusPainted(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        shopLogo3.setToolTipText("");

        pnlCards.setBackground(new java.awt.Color(255, 255, 255));
        pnlCards.setLayout(new java.awt.CardLayout());

        bluePnl.setBackground(new java.awt.Color(255, 255, 255));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setLayout(new java.awt.GridLayout(2, 4, 2, 2));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel54.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText("BROWNIE 1 PC");

        jLabel55.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel55.setText("P 25.00");

        brownie.setBackground(new java.awt.Color(0, 0, 51));
        brownie.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        brownie.setForeground(new java.awt.Color(255, 255, 255));
        brownie.setText("ADD TO CART");
        brownie.setBorderPainted(false);
        brownie.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        brownie.setFocusPainted(false);
        brownie.setFocusable(false);
        brownie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brownieActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(brownie, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(brownieImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel54, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel55, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(brownieImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel54)
                .addGap(43, 43, 43)
                .addComponent(jLabel55)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(brownie, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel10);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel56.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel56.setText("CHICKEN BURGER");

        jLabel57.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText("P 75.00");

        chickenBurger.setBackground(new java.awt.Color(0, 0, 51));
        chickenBurger.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        chickenBurger.setForeground(new java.awt.Color(255, 255, 255));
        chickenBurger.setText("ADD TO CART");
        chickenBurger.setBorderPainted(false);
        chickenBurger.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        chickenBurger.setFocusPainted(false);
        chickenBurger.setFocusable(false);
        chickenBurger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chickenBurgerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(chickenBurger, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chickenImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel56, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel57, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chickenImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel56)
                .addGap(43, 43, 43)
                .addComponent(jLabel57)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chickenBurger, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel11);

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel58.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel58.setText("SPAGHETTI");

        jLabel59.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel59.setText("P 100.00");

        spaghetti.setBackground(new java.awt.Color(0, 0, 51));
        spaghetti.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        spaghetti.setForeground(new java.awt.Color(255, 255, 255));
        spaghetti.setText("ADD TO CART");
        spaghetti.setBorderPainted(false);
        spaghetti.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        spaghetti.setFocusPainted(false);
        spaghetti.setFocusable(false);
        spaghetti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spaghettiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(spaghetti, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(spagImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel58, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel59, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(spagImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel58)
                .addGap(43, 43, 43)
                .addComponent(jLabel59)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spaghetti, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel12);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel60.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel60.setText("1 BOX OF BROWNIES");

        jLabel61.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel61.setText("P 230.00");

        boxBrownies.setBackground(new java.awt.Color(0, 0, 51));
        boxBrownies.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        boxBrownies.setForeground(new java.awt.Color(255, 255, 255));
        boxBrownies.setText("ADD TO CART");
        boxBrownies.setBorderPainted(false);
        boxBrownies.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        boxBrownies.setFocusPainted(false);
        boxBrownies.setFocusable(false);
        boxBrownies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxBrowniesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(boxBrownies, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(boxImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel60, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(boxImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel60)
                .addGap(43, 43, 43)
                .addComponent(jLabel61)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boxBrownies, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel13);

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel68.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setText("CALIFORNIA TWISTER");

        jLabel69.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setText("P 85.00");

        twister.setBackground(new java.awt.Color(0, 0, 51));
        twister.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        twister.setForeground(new java.awt.Color(255, 255, 255));
        twister.setText("ADD TO CART");
        twister.setBorderPainted(false);
        twister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        twister.setFocusPainted(false);
        twister.setFocusable(false);
        twister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twisterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(twister, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(twisterImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel68, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel69, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(twisterImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel68)
                .addGap(43, 43, 43)
                .addComponent(jLabel69)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(twister, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel14);

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel66.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel66.setText("MASHED POTATO");

        jLabel67.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel67.setText("P 50.00");

        mashed.setBackground(new java.awt.Color(0, 0, 51));
        mashed.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        mashed.setForeground(new java.awt.Color(255, 255, 255));
        mashed.setText("ADD TO CART");
        mashed.setBorderPainted(false);
        mashed.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        mashed.setFocusPainted(false);
        mashed.setFocusable(false);
        mashed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mashedActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(mashed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mashedImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel66, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel67, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mashedImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel66)
                .addGap(43, 43, 43)
                .addComponent(jLabel67)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mashed, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel15);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel64.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("TWISTER COMBO");

        jLabel65.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setText("P 160.00");

        twisterCombo.setBackground(new java.awt.Color(0, 0, 51));
        twisterCombo.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        twisterCombo.setForeground(new java.awt.Color(255, 255, 255));
        twisterCombo.setText("ADD TO CART");
        twisterCombo.setBorderPainted(false);
        twisterCombo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        twisterCombo.setFocusPainted(false);
        twisterCombo.setFocusable(false);
        twisterCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twisterComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(twisterCombo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tComboImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel64, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tComboImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel64)
                .addGap(43, 43, 43)
                .addComponent(jLabel65)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(twisterCombo, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel16);

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel62.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setText("BUTTERED CORN");

        jLabel63.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setText("P 220.00");

        butteredCorn.setBackground(new java.awt.Color(0, 0, 51));
        butteredCorn.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        butteredCorn.setForeground(new java.awt.Color(255, 255, 255));
        butteredCorn.setText("ADD TO CART");
        butteredCorn.setBorderPainted(false);
        butteredCorn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        butteredCorn.setFocusPainted(false);
        butteredCorn.setFocusable(false);
        butteredCorn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butteredCornActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(butteredCorn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cornImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel62, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel63, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cornImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel62)
                .addGap(43, 43, 43)
                .addComponent(jLabel63)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(butteredCorn, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel9.add(jPanel17);

        javax.swing.GroupLayout bluePnlLayout = new javax.swing.GroupLayout(bluePnl);
        bluePnl.setLayout(bluePnlLayout);
        bluePnlLayout.setHorizontalGroup(
            bluePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        bluePnlLayout.setVerticalGroup(
            bluePnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, 613, Short.MAX_VALUE)
        );

        pnlCards.add(bluePnl, "snacksCard");

        greenPnl.setBackground(new java.awt.Color(255, 255, 255));

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setLayout(new java.awt.GridLayout(2, 4, 2, 2));

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel70.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText("ALA KING ZINGER");

        jLabel71.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText("P 120.00");

        alaKing.setBackground(new java.awt.Color(0, 0, 51));
        alaKing.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        alaKing.setForeground(new java.awt.Color(255, 255, 255));
        alaKing.setText("ADD TO CART");
        alaKing.setBorderPainted(false);
        alaKing.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        alaKing.setFocusPainted(false);
        alaKing.setFocusable(false);
        alaKing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alaKingActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(alaKing, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(kingImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel70, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel71, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kingImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel70)
                .addGap(43, 43, 43)
                .addComponent(jLabel71)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(alaKing, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel19);

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));
        jPanel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel72.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel72.setText("ALA KING ZINGER WITH DRINK");

        jLabel73.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel73.setText("P 150.00");

        alaKingDrink.setBackground(new java.awt.Color(0, 0, 51));
        alaKingDrink.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        alaKingDrink.setForeground(new java.awt.Color(255, 255, 255));
        alaKingDrink.setText("ADD TO CART");
        alaKingDrink.setBorderPainted(false);
        alaKingDrink.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        alaKingDrink.setFocusPainted(false);
        alaKingDrink.setFocusable(false);
        alaKingDrink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alaKingDrinkActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(alaKingDrink, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(king2Img, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel72, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(king2Img, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel72)
                .addGap(43, 43, 43)
                .addComponent(jLabel73)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(alaKingDrink, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel20);

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel74.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setText("SPAGHETTI WITH DRINKS");

        jLabel75.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel75.setText("P 130.00");

        spaghettiDrink.setBackground(new java.awt.Color(0, 0, 51));
        spaghettiDrink.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        spaghettiDrink.setForeground(new java.awt.Color(255, 255, 255));
        spaghettiDrink.setText("ADD TO CART");
        spaghettiDrink.setBorderPainted(false);
        spaghettiDrink.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        spaghettiDrink.setFocusPainted(false);
        spaghettiDrink.setFocusable(false);
        spaghettiDrink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spaghettiDrinkActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(spaghettiDrink, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(spagMealImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel74, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel75, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(spagMealImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel74)
                .addGap(43, 43, 43)
                .addComponent(jLabel75)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spaghettiDrink, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel21);

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel76.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel76.setText("RICE 1 BOWL");

        jLabel77.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel77.setText("P 25.00");

        rice.setBackground(new java.awt.Color(0, 0, 51));
        rice.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        rice.setForeground(new java.awt.Color(255, 255, 255));
        rice.setText("ADD TO CART");
        rice.setBorderPainted(false);
        rice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rice.setFocusPainted(false);
        rice.setFocusable(false);
        rice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                riceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(rice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(riceImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel76, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel77, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(riceImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel76)
                .addGap(43, 43, 43)
                .addComponent(jLabel77)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rice, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel22);

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel84.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel84.setText("SISIG RICE BOWL");

        jLabel85.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel85.setText("P 130.00");

        sisig.setBackground(new java.awt.Color(0, 0, 51));
        sisig.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        sisig.setForeground(new java.awt.Color(255, 255, 255));
        sisig.setText("ADD TO CART");
        sisig.setBorderPainted(false);
        sisig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sisig.setFocusPainted(false);
        sisig.setFocusable(false);
        sisig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sisigActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sisig, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sisigImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel84, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel85, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sisigImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel84)
                .addGap(43, 43, 43)
                .addComponent(jLabel85)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sisig, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel23);

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));
        jPanel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel82.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel82.setText("1PC CHICKEN SPAGHETTI MEAL");

        jLabel83.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel83.setText("P 190.00");

        spaghettiMeal.setBackground(new java.awt.Color(0, 0, 51));
        spaghettiMeal.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        spaghettiMeal.setForeground(new java.awt.Color(255, 255, 255));
        spaghettiMeal.setText("ADD TO CART");
        spaghettiMeal.setBorderPainted(false);
        spaghettiMeal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        spaghettiMeal.setFocusPainted(false);
        spaghettiMeal.setFocusable(false);
        spaghettiMeal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spaghettiMealActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(spaghettiMeal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chickMealImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel82, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel83, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chickMealImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel82)
                .addGap(43, 43, 43)
                .addComponent(jLabel83)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spaghettiMeal, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel18.add(jPanel24);

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 305, Short.MAX_VALUE)
        );

        jPanel18.add(jPanel25);

        jPanel26.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 305, Short.MAX_VALUE)
        );

        jPanel18.add(jPanel26);

        javax.swing.GroupLayout greenPnlLayout = new javax.swing.GroupLayout(greenPnl);
        greenPnl.setLayout(greenPnlLayout);
        greenPnlLayout.setHorizontalGroup(
            greenPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        greenPnlLayout.setVerticalGroup(
            greenPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, 613, Short.MAX_VALUE)
        );

        pnlCards.add(greenPnl, "mealsCard");

        violetPnl.setBackground(new java.awt.Color(255, 255, 255));

        jPanel27.setBackground(new java.awt.Color(255, 255, 255));
        jPanel27.setLayout(new java.awt.GridLayout(2, 4, 2, 2));

        jPanel28.setBackground(new java.awt.Color(255, 255, 255));
        jPanel28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel86.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel86.setText("COFFEE FLOAT");

        jLabel87.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel87.setText("P 45.00");

        coffeeFloat.setBackground(new java.awt.Color(0, 0, 51));
        coffeeFloat.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        coffeeFloat.setForeground(new java.awt.Color(255, 255, 255));
        coffeeFloat.setText("ADD TO CART");
        coffeeFloat.setBorderPainted(false);
        coffeeFloat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        coffeeFloat.setFocusPainted(false);
        coffeeFloat.setFocusable(false);
        coffeeFloat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coffeeFloatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(coffeeFloat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(coffeeImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel86, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel87, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(coffeeImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel86)
                .addGap(43, 43, 43)
                .addComponent(jLabel87)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(coffeeFloat, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel28);

        jPanel29.setBackground(new java.awt.Color(255, 255, 255));
        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel88.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel88.setText("COKE REGULAR");

        jLabel89.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("P 35.00");

        coke.setBackground(new java.awt.Color(0, 0, 51));
        coke.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        coke.setForeground(new java.awt.Color(255, 255, 255));
        coke.setText("ADD TO CART");
        coke.setBorderPainted(false);
        coke.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        coke.setFocusPainted(false);
        coke.setFocusable(false);
        coke.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cokeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(coke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cokeImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel88, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel89, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cokeImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel88)
                .addGap(43, 43, 43)
                .addComponent(jLabel89)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(coke, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel29);

        jPanel30.setBackground(new java.awt.Color(255, 255, 255));
        jPanel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel90.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel90.setText("COKE ZERO");

        jLabel91.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel91.setText("P 35.00");

        cokeZero.setBackground(new java.awt.Color(0, 0, 51));
        cokeZero.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        cokeZero.setForeground(new java.awt.Color(255, 255, 255));
        cokeZero.setText("ADD TO CART");
        cokeZero.setBorderPainted(false);
        cokeZero.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cokeZero.setFocusPainted(false);
        cokeZero.setFocusable(false);
        cokeZero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cokeZeroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cokeZero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cokeZeroImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel90, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel91, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cokeZeroImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel90)
                .addGap(43, 43, 43)
                .addComponent(jLabel91)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cokeZero, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel30);

        jPanel31.setBackground(new java.awt.Color(255, 255, 255));
        jPanel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel92.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel92.setText("COKE ZERO FLOAT");

        jLabel93.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel93.setText("P 55.00");

        cokeZeroFloat.setBackground(new java.awt.Color(0, 0, 51));
        cokeZeroFloat.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        cokeZeroFloat.setForeground(new java.awt.Color(255, 255, 255));
        cokeZeroFloat.setText("ADD TO CART");
        cokeZeroFloat.setBorderPainted(false);
        cokeZeroFloat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cokeZeroFloat.setFocusPainted(false);
        cokeZeroFloat.setFocusable(false);
        cokeZeroFloat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cokeZeroFloatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cokeZeroFloat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cokeFloatImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel92, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel93, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cokeFloatImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel92)
                .addGap(43, 43, 43)
                .addComponent(jLabel93)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cokeZeroFloat, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel31);

        jPanel32.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel94.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel94.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel94.setText("ICED TEA REGULAR");

        jLabel95.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel95.setText("P 30.00");

        icedTea.setBackground(new java.awt.Color(0, 0, 51));
        icedTea.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        icedTea.setForeground(new java.awt.Color(255, 255, 255));
        icedTea.setText("ADD TO CART");
        icedTea.setBorderPainted(false);
        icedTea.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        icedTea.setFocusPainted(false);
        icedTea.setFocusable(false);
        icedTea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                icedTeaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(icedTea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(teaImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel94, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel95, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(teaImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel94)
                .addGap(43, 43, 43)
                .addComponent(jLabel95)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(icedTea, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel32);

        jPanel33.setBackground(new java.awt.Color(255, 255, 255));
        jPanel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel96.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel96.setText("ROYAL REGULAR");

        jLabel97.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel97.setText("P 35.00");

        royal.setBackground(new java.awt.Color(0, 0, 51));
        royal.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        royal.setForeground(new java.awt.Color(255, 255, 255));
        royal.setText("ADD TO CART");
        royal.setBorderPainted(false);
        royal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        royal.setFocusPainted(false);
        royal.setFocusable(false);
        royal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                royalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel33Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(royal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(royalImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel96, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel97, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(royalImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel96)
                .addGap(43, 43, 43)
                .addComponent(jLabel97)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(royal, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel33);

        jPanel34.setBackground(new java.awt.Color(255, 255, 255));
        jPanel34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel98.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel98.setText("SPRITE REGULAR");

        jLabel99.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel99.setText("P 35.00");

        sprite.setBackground(new java.awt.Color(0, 0, 51));
        sprite.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        sprite.setForeground(new java.awt.Color(255, 255, 255));
        sprite.setText("ADD TO CART");
        sprite.setBorderPainted(false);
        sprite.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sprite.setFocusPainted(false);
        sprite.setFocusable(false);
        sprite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spriteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sprite, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(spriteImg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel98, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(jLabel99, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(spriteImg, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel98)
                .addGap(43, 43, 43)
                .addComponent(jLabel99)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sprite, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        jPanel27.add(jPanel34);

        jPanel35.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel27.add(jPanel35);

        javax.swing.GroupLayout violetPnlLayout = new javax.swing.GroupLayout(violetPnl);
        violetPnl.setLayout(violetPnlLayout);
        violetPnlLayout.setHorizontalGroup(
            violetPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        violetPnlLayout.setVerticalGroup(
            violetPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, 613, Short.MAX_VALUE)
        );

        pnlCards.add(violetPnl, "drinksCard");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCards, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(shopLogo3, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(102, 102, 102)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(shopLogo3, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(pnlCards, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel4.setText("CURRENT ORDER");

        jButton7.setBackground(new java.awt.Color(0, 0, 153));
        jButton7.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Clear All Orders");
        jButton7.setBorderPainted(false);
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.setFocusPainted(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        cartOrders.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        cartOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCT NAME", "PRICE", "QUANTITY", "TOTAL PRICE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(cartOrders);

        removeItem.setBackground(new java.awt.Color(0, 0, 0));
        removeItem.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        removeItem.setForeground(new java.awt.Color(255, 255, 255));
        removeItem.setText("REMOVE ITEM");
        removeItem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        removeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeItemActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel5.setText("TOTAL:");

        totalAmountOrders.setFont(new java.awt.Font("Segoe UI Black", 1, 17)); // NOI18N
        totalAmountOrders.setForeground(new java.awt.Color(204, 0, 51));
        totalAmountOrders.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        totalAmountOrders.setText("P 0.0");

        placeOrder.setBackground(new java.awt.Color(0, 0, 0));
        placeOrder.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        placeOrder.setForeground(new java.awt.Color(255, 255, 255));
        placeOrder.setText("PLACE ORDER");
        placeOrder.setBorder(null);
        placeOrder.setBorderPainted(false);
        placeOrder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        placeOrder.setFocusPainted(false);
        placeOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                placeOrderActionPerformed(evt);
            }
        });

        back.setBackground(new java.awt.Color(0, 0, 0));
        back.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 255));
        back.setText("BACK");
        back.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(totalAmountOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(placeOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(56, 56, 56)
                                .addComponent(jButton7)))
                        .addGap(0, 49, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(removeItem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 431, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(removeItem, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(back, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(totalAmountOrders, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(placeOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(76, 76, 76)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(184, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout mainAppLayout = new javax.swing.GroupLayout(mainApp);
        mainApp.setLayout(mainAppLayout);
        mainAppLayout.setHorizontalGroup(
            mainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainAppLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(157, Short.MAX_VALUE))
        );
        mainAppLayout.setVerticalGroup(
            mainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainAppLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(mainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        mainTab.addTab("tab3", mainApp);

        getContentPane().add(mainTab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 1550, 800));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    public JTabbedPane getTab(){
        return mainTab;
    }
    
    // Remove all the items in the arraylist
    public void removeAllItems(){
        cartItems.clear();
        updateTable();
    }
    
    // Adding an item to the arraylist
    private void addToCart(FoodItem item){
        for (int index=0; index<cartItems.size(); index++){
            FoodItem food = cartItems.get(index);
            if (food.getName().equals(item.getName())){
                food.setQuantity((food.getQuantity()+item.getQuantity()));
                updateTable();
                return;
            } 
        }
        
        cartItems.add(item);
        updateTable();
    }
    
    // Deleting or Removing Item in the arraylist
    private void deleteItem(int row){
        cartItems.remove(row);
        updateTable();
    }
    
    //Updating the total Amount
    private double updateTotalAmount(){
        double initialAmount = 0;
        for (int index=0; index<cartItems.size(); index++){
            FoodItem item = cartItems.get(index);
            initialAmount += item.getTotalAmount();
        }
        
        totalAmountOrders.setText("P "+initialAmount);
        return initialAmount;
    }
    
    // Updating the table
    private void updateTable(){
        model.setRowCount(0);
        for (int index=0; index<cartItems.size(); index++){
            FoodItem item = cartItems.get(index);
            model.addRow(new Object[]{
                item.getName(),
                item.getPrice(),
                item.getQuantity(),
                item.getTotalAmount()
            });
        }
        
        updateTotalAmount();
    }
    
    // This is for the insertion of Snack and Meals in arraylist
    private void chooseSnacksMeal(String itemPath, String name, double price){
        ImageIcon icon = new ImageIcon(itemPath);
        Image resizeIcon = icon.getImage().getScaledInstance(80, 50, Image.SCALE_SMOOTH);
        ImageIcon icon2 = new ImageIcon(resizeIcon);
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(spinner, BorderLayout.CENTER);
        
        int option = JOptionPane.showConfirmDialog(null, 
                panel,
                "Select A Quantity",
                JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                icon2);
        
        if (option== JOptionPane.OK_OPTION){
            int selectedQuantity = (int) spinner.getValue();
            FoodItem foodItem = new FoodItem(name, price, selectedQuantity);
            addToCart(foodItem);
            
        }else {
            JOptionPane.showMessageDialog(null, "Order Canceled", "CANCELED", JOptionPane.INFORMATION_MESSAGE, icon2);
        }
    }
    
    // This is for the insertion of Drinks in arraylist
    private void chooseDrinks(String itemPath, String name, double price){
        ImageIcon icon = new ImageIcon(itemPath);
        Image resizeIcon = icon.getImage().getScaledInstance(80, 50, Image.SCALE_SMOOTH);
        ImageIcon icon2 = new ImageIcon(resizeIcon);
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(spinner, BorderLayout.CENTER);
        
        int option = JOptionPane.showConfirmDialog(null, 
                panel,
                "Select A Quantity",
                JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                icon2);
        
        if (option== JOptionPane.OK_OPTION){
            int selectedQuantity = (int) spinner.getValue();
            
            String[] size = {"Regular", "Large"};
            JComboBox<String> comboBox = new JComboBox<>(size);
            
            int choose = JOptionPane.showConfirmDialog(null, 
                    comboBox, 
                    "Select Size of the Drinks \n Large: +20 Pesos", 
                    JOptionPane.OK_CANCEL_OPTION, 
                    JOptionPane.QUESTION_MESSAGE, 
                    icon2);
            
            if (choose==JOptionPane.OK_OPTION){
                String selectedSize = (String) comboBox.getSelectedItem();
                Drinks foodItem = new Drinks(name, price, selectedQuantity, selectedSize);
                foodItem.updatePrice();
                addToCart(foodItem);
            }else{
                JOptionPane.showMessageDialog(null, "Order Canceled", "CANCELED", JOptionPane.INFORMATION_MESSAGE, icon2);
            }
    
        }else {
            JOptionPane.showMessageDialog(null, "Order Canceled", "CANCELED", JOptionPane.INFORMATION_MESSAGE, icon2);
        }
    }
    
    private void startShopMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startShopMouseClicked
        mainTab.setSelectedIndex(1); // Going to the second tab
    }//GEN-LAST:event_startShopMouseClicked

    private void dineInMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dineInMouseClicked
        orderTypes = "DINE  IN"; //Choosing Dine in
        mainTab.setSelectedIndex(2); // Going to third tab
        
    }//GEN-LAST:event_dineInMouseClicked

    private void takeOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_takeOutMouseClicked
        orderTypes = "TAKE OUT"; //Choosing Take out
        mainTab.setSelectedIndex(2); // Going to third tab
        
    }//GEN-LAST:event_takeOutMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        cardLayout.show(pnlCards, "snacksCard");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        cardLayout.show(pnlCards, "mealsCard");
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        cardLayout.show(pnlCards, "drinksCard");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void brownieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brownieActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/BRWNY-M1.jpg", "Brownie", 25);
    }//GEN-LAST:event_brownieActionPerformed

    private void chickenBurgerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chickenBurgerActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/CHICKENBURGER.jpg", "Chicken Burger", 75);
    }//GEN-LAST:event_chickenBurgerActionPerformed

    private void spaghettiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spaghettiActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/SPAG.jpg", "Spaghetti", 100);
    }//GEN-LAST:event_spaghettiActionPerformed

    private void boxBrowniesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxBrowniesActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/HOLBRWNYBOX.jpg", "Box Brownies", 230);
    }//GEN-LAST:event_boxBrowniesActionPerformed

    private void butteredCornActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butteredCornActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/BCORNPLT.jpg", "Buttered Corn", 220);
    }//GEN-LAST:event_butteredCornActionPerformed

    private void twisterComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twisterComboActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/TWISTERCBO.jpg", "Twister Combo", 160);
    }//GEN-LAST:event_twisterComboActionPerformed

    private void mashedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mashedActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/MASHED.jpg", "Mashed Potato", 50);
    }//GEN-LAST:event_mashedActionPerformed

    private void twisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twisterActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/CALMAKITWISTER.jpg", "Calif. Twister", 85);
    }//GEN-LAST:event_twisterActionPerformed

    private void alaKingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alaKingActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/AKZSMAC.jpg", "Ala King Zinger", 120);
    }//GEN-LAST:event_alaKingActionPerformed

    private void alaKingDrinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alaKingDrinkActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/AKZSMBCORNCBO.jpg", "A.K.Z+ Drink", 150);
    }//GEN-LAST:event_alaKingDrinkActionPerformed

    private void spaghettiDrinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spaghettiDrinkActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/ASPAGCBO.jpg", "Spag.+ Drinks", 130);
    }//GEN-LAST:event_spaghettiDrinkActionPerformed

    private void riceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_riceActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/RICE.jpg", "Rice Bowl", 25);
    }//GEN-LAST:event_riceActionPerformed

    private void spaghettiMealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spaghettiMealActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/SPAGMEAL.jpg", "1PC C. Spag", 190);
    }//GEN-LAST:event_spaghettiMealActionPerformed

    private void sisigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sisigActionPerformed
        chooseSnacksMeal("src/main/java/com/mycompany/snackondgo/icons/RBSISIG.jpg", "Sisig Rice", 130);
    }//GEN-LAST:event_sisigActionPerformed

    private void coffeeFloatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_coffeeFloatActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/CFFEEFLOAT.jpg", "Coffee F.", 45);
    }//GEN-LAST:event_coffeeFloatActionPerformed

    private void cokeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cokeActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/COKE-R.jpg", "Coke", 35);
    }//GEN-LAST:event_cokeActionPerformed

    private void cokeZeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cokeZeroActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/COKEZERO-R.jpg", "C.Zero", 35);
    }//GEN-LAST:event_cokeZeroActionPerformed

    private void cokeZeroFloatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cokeZeroFloatActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/COKEZEROFLOAT.jpg", "C.Zero F.", 55);
    }//GEN-LAST:event_cokeZeroFloatActionPerformed

    private void icedTeaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_icedTeaActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/ICEDTEA.jpg", "Iced Tea", 30);
    }//GEN-LAST:event_icedTeaActionPerformed

    private void royalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_royalActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/ROYAL-R.jpg", "Royal", 35);
    }//GEN-LAST:event_royalActionPerformed

    private void spriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spriteActionPerformed
        chooseDrinks("src/main/java/com/mycompany/snackondgo/icons/SPRITE-R.jpg", "Sprite", 35);
    }//GEN-LAST:event_spriteActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        removeAllItems();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void removeItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeItemActionPerformed
        int selectedRow = cartOrders.getSelectedRow(); // Getting the selected row from the cart table 
        if (selectedRow != -1) deleteItem(selectedRow); // Delete the selected Row
        else {
            JOptionPane.showMessageDialog(null, "No Item Selected"); // Error when theres no selected row
        }
    }//GEN-LAST:event_removeItemActionPerformed

    private void placeOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_placeOrderActionPerformed
        if (!cartItems.isEmpty()){
            ReceiptForm receipt = new ReceiptForm(); // Make an instance of ReceiptForm
            receipt.setMainApp(this); // Getting the reference of this tab
            receipt.setReceipt(cartItems, orderTypes); //Setting the receipt for the list of orders
            receipt.setTotal(updateTotalAmount()); // Updating the total Amount in the payment frame
            receipt.setVisible(true); // The payment frame will appear
        }else JOptionPane.showMessageDialog(null, "Please Choose An Order", "No Item in the Cart", JOptionPane.WARNING_MESSAGE); // Displaying an error if theres no order in the cart

    }//GEN-LAST:event_placeOrderActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        mainTab.setSelectedIndex(1);
    }//GEN-LAST:event_backActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShopStart().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton alaKing;
    private javax.swing.JButton alaKingDrink;
    private javax.swing.JButton back;
    private javax.swing.JPanel bluePnl;
    private javax.swing.JButton boxBrownies;
    private javax.swing.JLabel boxImg;
    private javax.swing.JButton brownie;
    private javax.swing.JLabel brownieImg;
    private javax.swing.JButton butteredCorn;
    private javax.swing.JTable cartOrders;
    private javax.swing.JLabel chickMealImg;
    private javax.swing.JButton chickenBurger;
    private javax.swing.JLabel chickenImg;
    private javax.swing.JButton coffeeFloat;
    private javax.swing.JLabel coffeeImg;
    private javax.swing.JButton coke;
    private javax.swing.JLabel cokeFloatImg;
    private javax.swing.JLabel cokeImg;
    private javax.swing.JButton cokeZero;
    private javax.swing.JButton cokeZeroFloat;
    private javax.swing.JLabel cokeZeroImg;
    private javax.swing.JLabel cornImg;
    private javax.swing.JLabel dineIn;
    private javax.swing.JLabel firstLogo;
    private javax.swing.JPanel greenPnl;
    private javax.swing.JButton icedTea;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel king2Img;
    private javax.swing.JLabel kingImg;
    private javax.swing.JPanel mainApp;
    private javax.swing.JTabbedPane mainTab;
    private javax.swing.JButton mashed;
    private javax.swing.JLabel mashedImg;
    private javax.swing.JPanel orderType;
    private javax.swing.JButton placeOrder;
    private javax.swing.JPanel pnlCards;
    private javax.swing.JButton removeItem;
    private javax.swing.JButton rice;
    private javax.swing.JLabel riceImg;
    private javax.swing.JButton royal;
    private javax.swing.JLabel royalImg;
    private javax.swing.JLabel shopLogo3;
    private javax.swing.JLabel shoplogo;
    private javax.swing.JButton sisig;
    private javax.swing.JLabel sisigImg;
    private javax.swing.JLabel spagImg;
    private javax.swing.JLabel spagMealImg;
    private javax.swing.JButton spaghetti;
    private javax.swing.JButton spaghettiDrink;
    private javax.swing.JButton spaghettiMeal;
    private javax.swing.JButton sprite;
    private javax.swing.JLabel spriteImg;
    private javax.swing.JPanel startShop;
    private javax.swing.JLabel tComboImg;
    private javax.swing.JLabel takeOut;
    private javax.swing.JLabel teaImg;
    private javax.swing.JLabel totalAmountOrders;
    private javax.swing.JButton twister;
    private javax.swing.JButton twisterCombo;
    private javax.swing.JLabel twisterImg;
    private javax.swing.JPanel violetPnl;
    // End of variables declaration//GEN-END:variables
}
