package com.mycompany.snackondgo;
import java.util.ArrayList;

public abstract class GenerateReceipt {
    private StringBuilder receipt = new StringBuilder(); //Building the receipt
    private String customerType = ""; // Student, Regular or Senior/PWD
    private String orderType = ""; // Dine in or Take out
    private double discount, discountAmount, totalAmount, discountedPrice;
    private ArrayList<FoodItem> orders; //Getting the references of the orders
    private double change, cash; // Variable for change and cash

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public double getCash() {
        return cash;
    }

    public void setCash(double cash) {
        this.cash = cash;
    }

    public double getChange() {
        return change;
    }

    public void setChange(double cashAmount, double discountedprice) {
        change = cashAmount - discountedprice;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
    
    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getDiscountedPrice() {
        return discountedPrice;
    }

    public void setDiscountedPrice(double total, double discountAmount) {
        this.discountedPrice = total-discountAmount;
    }

    public ArrayList<FoodItem> getOrders() {
        return orders;
    }

    public void setOrders(ArrayList<FoodItem> orders) {
        this.orders = orders;
    }
    
    
    public StringBuilder getReceipt(){
        return receipt;
    }   
    
    public abstract void makeReceipt();
    public abstract void printHeader();
    public abstract void printFooter();
 
}
