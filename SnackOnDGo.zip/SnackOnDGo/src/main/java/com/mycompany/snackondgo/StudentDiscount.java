
package com.mycompany.snackondgo;

public class StudentDiscount extends Discount {
    @Override
    public double calculate (double totalAmount){
        return totalAmount*0.05;
    }
}
