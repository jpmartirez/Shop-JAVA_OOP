
package com.mycompany.snackondgo;

public class SnackOnDGo {

    public static void main(String[] args) {
        ShopStart shop = new ShopStart();
        shop.setVisible(true);
    }
}
