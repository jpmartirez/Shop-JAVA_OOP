
package com.mycompany.snackondgo;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Receipt extends GenerateReceipt{
    
    private Discount discountStrategy;
    
    @Override
    public void makeReceipt(){
        printHeader();
        getReceipt().append(String.format("%-15s %-8s %-10s %-10s\n", "Item", "Qty", "Price", "Total"));
        getReceipt().append("\n");
        for (FoodItem item : getOrders()) {
            getReceipt().append(String.format("%-15s %-8d %-10.2f %-10.2f\n",
                    item.getName(), item.getQuantity(), item.getPrice(), item.getTotalAmount()));
        }
    }
    
    @Override
    public void printHeader(){
        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        getReceipt().append("================================================\n");
        getReceipt().append("Date: ");
        getReceipt().append(currentDate);
        getReceipt().append("\n");
        getReceipt().append("================================================\n");
        getReceipt().append(" ------------------ ").append(getOrderType()).append(" ------------------ \n\n");
    }
    
    @Override
    public void printFooter(){
        getReceipt().append("\n\n\n\n================================================\n");
        getReceipt().append("\t         WE LOVE TO HEAR YOU               \n");
        getReceipt().append("\t        SHARE YOUR FEEDBACK AT           \n");
        getReceipt().append("\t     www.snackondgo.feedback.com        \n");
        getReceipt().append("\n");
        getReceipt().append("       THANK YOU , AND PLEASE COME AGAIN          \n");
        getReceipt().append("================================================\n");
    }
    
    public void setDiscountStrategy(Discount discountStrategy){
        this.discountStrategy = discountStrategy;
    }

    public void calculatePayment(String customerType, double cashAmount) {
        setCustomerType(customerType);
        setCash(cashAmount);
        
        double totalAmount = 0;
        for (FoodItem item : getOrders()) {
            totalAmount += item.getTotalAmount();
        }

        setTotalAmount(totalAmount);
        
        if (customerType.equals("STUDENT")) setDiscountStrategy(new StudentDiscount());
        else if (customerType.equals("SENIOR CITIZEN / PWD")) setDiscountStrategy(new SeniorDiscount());
        else setDiscountStrategy(new Discount());
        
        
        setDiscountAmount(discountStrategy.calculate(getTotalAmount()));
        setDiscountedPrice(getTotalAmount(), getDiscountAmount());
        setChange(getCash(), getDiscountedPrice());
    }

    public StringBuilder printPayment(){
        getReceipt().setLength(0);
        
        getReceipt().append("================================================\n\n");
        getReceipt().append("CUSTOMER TYPE: ").append(getCustomerType()).append("\n");
        getReceipt().append("INITIAL AMOUNT TO PAY: P").append(getTotalAmount()).append("\n");
        getReceipt().append("DISCOUNT: P").append(getDiscountAmount()).append("\n");
        getReceipt().append("\n");
        getReceipt().append("CASH AMOUNT: P").append(getCash()).append("\n");
        getReceipt().append("TOTAL AMOUNT TO PAY: P").append(getDiscountedPrice()).append("\n");
        getReceipt().append("\n");
        getReceipt().append("CHANGE: P").append(getChange()).append("\n");

        printFooter();
        return getReceipt();
    }
}
