package com.mycompany.snackondgo;

public class Discount {
    public double calculate (double totalAmount){
        return 0;
    }
}